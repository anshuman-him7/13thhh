Open index.html in a browser or upload it to GitHub Pages.
Edit the meeting date in the JavaScript:
const meet=new Date("2025-01-01");
